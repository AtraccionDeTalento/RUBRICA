@echo off
chcp 65001 >nul
title Instalación - Sistema de Evaluación Docente USIL

echo.
echo ═══════════════════════════════════════════════════════════════════
echo    INSTALACIÓN DEL SISTEMA DE EVALUACIÓN DOCENTE
echo    Talento y Cultura - USIL
echo ═══════════════════════════════════════════════════════════════════
echo.

:: Obtener directorio actual del script
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

echo [1/5] Verificando Python instalado...
python --version 2>nul
if errorlevel 1 (
    echo.
    echo ══════════════════════════════════════════════════════════════════
    echo    ✗ ERROR: Python no está instalado o no está en el PATH
    echo.
    echo    Descarga Python desde: https://www.python.org/downloads/
    echo    Durante la instalación, marca "Add Python to PATH"
    echo ══════════════════════════════════════════════════════════════════
    pause
    exit /b 1
)
echo       ✓ Python encontrado

echo [2/5] Creando entorno virtual...
if exist ".venv-1" (
    echo       ✓ Entorno virtual ya existe
) else (
    python -m venv .venv-1
    if errorlevel 1 (
        echo       ✗ ERROR al crear entorno virtual
        pause
        exit /b 1
    )
    echo       ✓ Entorno virtual creado
)

echo [3/5] Activando entorno virtual...
call .venv-1\Scripts\activate.bat
echo       ✓ Entorno activado

echo [4/5] Actualizando pip...
python -m pip install --upgrade pip --quiet
echo       ✓ pip actualizado

echo [5/5] Instalando dependencias...
echo       Esto puede tomar varios minutos...
pip install -r bot_evaluacion_docente\requirements.txt
if errorlevel 1 (
    echo       ✗ ERROR al instalar dependencias
    pause
    exit /b 1
)
echo       ✓ Dependencias instaladas

echo.
echo ═══════════════════════════════════════════════════════════════════
echo    ✓ INSTALACIÓN COMPLETADA EXITOSAMENTE
echo.
echo    Para iniciar el sistema, ejecuta:
echo    → INICIAR_EVALUACION.bat
echo.
echo    O haz doble clic en el archivo INICIAR_EVALUACION.bat
echo ═══════════════════════════════════════════════════════════════════
echo.

pause
