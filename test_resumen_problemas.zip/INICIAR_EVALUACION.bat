@echo off
chcp 65001 >nul
title Sistema de Evaluación Docente USIL

echo.
echo ═══════════════════════════════════════════════════════════════════
echo    SISTEMA DE EVALUACIÓN DOCENTE - USIL
echo    Talento y Cultura
echo ═══════════════════════════════════════════════════════════════════
echo.

:: Obtener directorio actual del script
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

echo [1/4] Verificando entorno...

:: Buscar entorno virtual
if exist ".venv-1\Scripts\activate.bat" (
    set "VENV_PATH=.venv-1"
    echo       ✓ Entorno virtual encontrado: .venv-1
) else if exist ".venv\Scripts\activate.bat" (
    set "VENV_PATH=.venv"
    echo       ✓ Entorno virtual encontrado: .venv
) else if exist "venv\Scripts\activate.bat" (
    set "VENV_PATH=venv"
    echo       ✓ Entorno virtual encontrado: venv
) else (
    echo       ✗ ERROR: No se encontró entorno virtual
    echo.
    echo       Debes crear un entorno virtual primero:
    echo         python -m venv .venv-1
    echo         .venv-1\Scripts\activate
    echo         pip install -r bot_evaluacion_docente\requirements.txt
    echo.
    pause
    exit /b 1
)

echo [2/4] Activando entorno virtual...
call "%VENV_PATH%\Scripts\activate.bat"
echo       ✓ Entorno activado

echo [3/4] Verificando dependencias...
python -c "import flask, pandas, requests, bs4" 2>nul
if errorlevel 1 (
    echo       ⚠ Faltan dependencias. Instalando...
    pip install -r bot_evaluacion_docente\requirements.txt --quiet
    echo       ✓ Dependencias instaladas
) else (
    echo       ✓ Dependencias verificadas
)

echo [4/4] Iniciando servidor web...
echo.
echo ═══════════════════════════════════════════════════════════════════
echo    🌐 El servidor se iniciará en: http://localhost:5000
echo    📋 Abre esa URL en tu navegador para usar el sistema
echo    ❌ Para cerrar, presiona Ctrl+C o cierra esta ventana
echo ═══════════════════════════════════════════════════════════════════
echo.

:: Abrir navegador automáticamente después de 2 segundos
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:5000"

:: Iniciar servidor
cd bot_evaluacion_docente
python run_server.py

:: Si el servidor se cierra, mostrar mensaje
echo.
echo ═══════════════════════════════════════════════════════════════════
echo    Servidor detenido.
echo ═══════════════════════════════════════════════════════════════════
pause
